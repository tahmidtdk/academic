#include"define.h"
#include"function.h"

int main(){

    while(true){
        int chk= main_menu();
        if(chk==-1) break;
    }

    return 0;
}
