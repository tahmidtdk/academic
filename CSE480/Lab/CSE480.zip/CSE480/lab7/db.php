<?php 

$db = mysqli_connect('localhost','root','','480') or die('Connection error!');

?>