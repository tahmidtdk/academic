<?php
	$db = mysqli_connect('localhost','root','','registration') or die('connectionerror');
?>