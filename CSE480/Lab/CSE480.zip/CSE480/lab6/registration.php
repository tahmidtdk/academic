<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body>
	
	<fieldset>
		<form action="reg.php" method="POST">
			Id<br>
			<input type="text" name="id"><br>
			Password<br>
			<input type="Password" name="password"><br>
			Confirm Password<br>
			<input type="Password" name="confirmpassword"><br>
			Name<br>
			<input type="text" name="name"><br>
			Email<br>
			<input type="text" name="email"><br>
			User Type [User/Admin]<br>
			<select name="type">
				<option value="user">User</option>
				<option value="admin">Admin</option>
			</select><br><br>
			<input type="submit" name="register" value="Register">
			<a href="loginForm.php">Login</a>
		</form>
	</fieldset>
	<?php 
		session_start();
		if(isset($_SESSION['error']))
		{
			echo '<li>'. $_SESSION['error'].'</li>';
		}
	?>
</body>
</html>