<?php
	require 'db.php';
	session_start();
	$useremail = $_POST['userEmail'];
	$userpassword = $_POST['userPassword'];
	$rememberMe = $_POST['rememberMe'];

	if(empty($_POST['userEmail']) || empty($_POST['userPassword']))
	{
		$_SESSION['error'] = 'Input field cannot be empty';
		header('Location: loginCheck.php');
	}
	else
	{	
		if(!filter_var($email,FILTER_VALIDATE_EMAIL))
		{
			$_SESSION['error'] = 'ERROR: Invalid EMAIL format';
			header('Location: loginCheck.php');
		}

	}

	$sql = "SELECT * FROM user WHERE `Id` = '$id' AND `Password` = '$password'";
	$act = $db->query($sql);
	$row = mysqli_num_rows($act);

	foreach ($act as $key) {
		$name = $key['name'];
		$type = $key['type'];
	}
	
	if($row >= 1)
	{
		if($rememberme == 'check')
		{
			setcookie('login','yes',time() + 86400);
			setcookie('id',$id,time() + 86400);
			setcookie('name',$name,time() + 86400);
			setcookie('type',$type,time() + 86400);
		}

		$_SESSION['id'] = $id;
		$_SESSION['type'] = $type;
		$_SESSION['name'] = $name;

		header('Location: home.php');
	}
	else
	{
		$_SESSION['error'] = 'Id / Password is not match';
		header('Location: loginForm.php');
	}
?>
	
	if(empty($_POST['userEmail']) || empty($_POST['userPassword']))
	{
		echo "All input field is required !!!!";
	}
	else
	{	
		if(!filter_var($email,FILTER_VALIDATE_EMAIL))
		{
			echo "ERROR: Invalid EMAIL format";
		}

	}