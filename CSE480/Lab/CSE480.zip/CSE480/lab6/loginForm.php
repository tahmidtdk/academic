<?php 
	require 'db.php';
	session_start();

	if(isset($_SESSION['id'])){
		header('Location: home.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<fieldset>
	<form action="loginCheck.php" method="POST">
		Id<br>
		<input type="text" name="id"><br>
		Password<br>
		<input type="Password" name="password"><br><br>
		<input type="checkbox" name="rememberme" value="rememberme">Remember Me<br><br>
		<input type="submit" name="login" value="Login">
		<a href="register.php">Register</a>
	</form>
</fieldset>
<?php 

		if(isset($_SESSION['error'])){
			echo '<li>'. $_SESSION['error'] . '</li>';
		}

?>
</body>
</html>