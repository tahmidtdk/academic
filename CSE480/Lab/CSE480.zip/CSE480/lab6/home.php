<?php
	
	require 'db.php';
	session_start();

	if(!isset($_SESSION['id']))
	{
		header('Location: loginForm.php');
	}

	if(isset($_COOKIE['login']))
	{
		$_SESSION['id']  = $_COOKIE['id'];
		$_SESSION['type'] = $_COOKIE['type'];
		$_SESSION['name'] = $_COOKIE['name'];
	}
	

?>
<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
</head>
<body>
<div align="center">
	<h1>Welcome <?php echo $_SESSION['name']; ?>!</h1>
	<a href="profile.php">Profile</a><br>
	<a href="changePassword.php">Change Password</a><br>

<?php
	if($_SESSION['type'] == 'admin')
	{ ?>
		<a href="viewUser.php">View Users</a>
<?php
	}
?>
	<a href="logout.php">Logout</a><br>
</div>


</body>
</html>