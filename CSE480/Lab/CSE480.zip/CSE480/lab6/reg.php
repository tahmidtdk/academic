<?php
	
	require 'db.php';
	session_start();

	$id = $_POST['id'];
	$password = $_POST['password'];
	$confirmPassword = $_POST['confirmpassword'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$type = $_POST['type']; 

	if(empty($id) || empty($password) || empty($name) || empty($email) || empty($type))
	{
		$_SESSION['error'] = 'Input field cannot be empty';
		header('Location: registration.php');
	}
	else
	{
		if($password == $confirmPassword)
		{
			$sql = "SELECT id FROM user WHERE `Id` = '$id'";
			$sql2 = "INSERT INTO user(`Id`,`Password`,`Name`,`Email`,`Type`) VALUES('$id','$password','$name','$email','$type')";
			$act = $db->query($sql);
			$row = mysqli_num_rows($act); 
			if($row >= 1)
			{
				$_SESSION['error'] = 'ID already registered';
			}
			else
			{
				$act2 = $db->query($sql2);
				header('Location: loginForm.php');
			}
		}
		else{
		
			$_SESSION['error'] = 'Password not match';
			header('Location: registration.php');
		}
	}
	
	 


?>