<?php 

$db = mysqli_connect('localhost','shaykh','147461','cse480') or die('Connection error!');

?>