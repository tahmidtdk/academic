
struct in_vari{
    char ch;
    bool value;
    int priority;
    in_vari(){
     ch='0';
     priority=0;
    }
};

in_vari data[500];
