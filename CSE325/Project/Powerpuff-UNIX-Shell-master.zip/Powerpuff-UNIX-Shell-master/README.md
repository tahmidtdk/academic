# Powerpuff-UNIX-Shell

working commands cd, ls, mkdir, touch, cp(copy), cat, echo, clear, exit

# Documentation:
In Linux terminal this commands can be used to setup Powerpuff shell.

`$ wget https://github.com/shaykhsiddique/Powerpuff-UNIX-Shell/blob/master/powerpuff_unix_shell.c`

`$ gcc powerpuff_unix_shell.c –o powerpuff`

`$ ./powerpuff`

